<center>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- ads1 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-2680085766880076"
     data-ad-slot="1838419727"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center>