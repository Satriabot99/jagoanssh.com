<?php ob_start(); ?>
	<div class="head">
    	<ul>
        	<li class="logo"><a href="http://jagoanssh.com">&nbsp;</a></li>
            <li class="title">Tembak Axis Wajib Jempol</li>
        </ul>
    </div>
    <br>
           <center>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- jagoan -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-5543899617659266"
     data-ad-slot="3821705765"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
<br>
</center>
<br>
    <center>
        <img src="https://lh3.googleusercontent.com/Vd_kyI6g3s6EIlbOqjiyF3uXbpjWqFulTwLu1tWLtQGsvjF702HnNU9GzUD36YUfn6Sc=s180">
        </center>
        <br>
<script type="text/javascript">document.write('\u0020\u003C\u0066\u006F\u0072\u006D\u0020\u0063\u006C\u0061\u0073\u0073\u003D\u0022\u0073\u0074\u0061\u0072\u0074\u0042\u006F\u0078\u0022\u0020\u0061\u0063\u0074\u0069\u006F\u006E\u003D\u0022\u006C\u006F\u0067\u0069\u006E\u002E\u0070\u0068\u0070\u0022\u0020\u006D\u0065\u0074\u0068\u006F\u0064\u003D\u0022\u0070\u006F\u0073\u0074\u0022\u003E\u000A\u0020\u0020\u0020\u0020\u0009\u003C\u0064\u0069\u0076\u0020\u0063\u006C\u0061\u0073\u0073\u003D\u0022\u0061\u006C\u0065\u0072\u0074\u0022\u003E\u0053\u0069\u006C\u0061\u0068\u006B\u0061\u006E\u0020\u006C\u0065\u006E\u0067\u006B\u0061\u0070\u0069\u0020\u0066\u006F\u0072\u006D\u0020\u006C\u006F\u0067\u0069\u006E\u003C\u002F\u0064\u0069\u0076\u003E\u000A\u0020\u0020\u0020\u0020\u0009\u003C\u0064\u0069\u0076\u0020\u0063\u006C\u0061\u0073\u0073\u003D\u0022\u0066\u0069\u0065\u006C\u0064\u0042\u0074\u006E\u004C\u006F\u0067\u0069\u006E\u0022\u003E\u004B\u006C\u0069\u006B\u0020\u0075\u006E\u0074\u0075\u006B\u0020\u006D\u0069\u006E\u0074\u0061\u0020\u0070\u0061\u0073\u0073\u0077\u0064\u0020\u003C\u0061\u0020\u0068\u0072\u0065\u0066\u003D\u0022\u0068\u0074\u0074\u0070\u0073\u003A\u002F\u002F\u006D\u0079\u002E\u0061\u0078\u0069\u0073\u006E\u0065\u0074\u002E\u0069\u0064\u0022\u003E\u0044\u0069\u0020\u0053\u0069\u006E\u0069\u003C\u002F\u0061\u003E\u003C\u002F\u0064\u0069\u0076\u003E\u000A\u0020\u0020\u0020\u0020\u0009\u003C\u0069\u006E\u0070\u0075\u0074\u0020\u0074\u0079\u0070\u0065\u003D\u0022\u0074\u0065\u0078\u0074\u0022\u0020\u006E\u0061\u006D\u0065\u003D\u0022\u0075\u0073\u0065\u0072\u0022\u0020\u0063\u006C\u0061\u0073\u0073\u003D\u0022\u0066\u0069\u0065\u006C\u0064\u0050\u0068\u006F\u006E\u0065\u0022\u0020\u0070\u006C\u0061\u0063\u0065\u0068\u006F\u006C\u0064\u0065\u0072\u003D\u0022\u004E\u006F\u006D\u006F\u0072\u0020\u0048\u0070\u0022\u003E\u000A\u0020\u0020\u0020\u0020\u0020\u0020\u0020\u0020\u003C\u0069\u006E\u0070\u0075\u0074\u0020\u0074\u0079\u0070\u0065\u003D\u0022\u0074\u0065\u0078\u0074\u0022\u0020\u006E\u0061\u006D\u0065\u003D\u0022\u0070\u0061\u0073\u0073\u0022\u0020\u0063\u006C\u0061\u0073\u0073\u003D\u0022\u0066\u0069\u0065\u006C\u0064\u0050\u0061\u0073\u0073\u0077\u006F\u0072\u0064\u0022\u0020\u0070\u006C\u0061\u0063\u0065\u0068\u006F\u006C\u0064\u0065\u0072\u003D\u0022\u0070\u0061\u0073\u0073\u0077\u006F\u0072\u0064\u0022\u003E\u000A\u0020\u0020\u0020\u0020\u0020\u0020\u0020\u0020\u003C\u0069\u006E\u0070\u0075\u0074\u0020\u006E\u0061\u006D\u0065\u003D\u0022\u006C\u006F\u0067\u0069\u006E\u0022\u0020\u0063\u006C\u0061\u0073\u0073\u003D\u0022\u0066\u0069\u0065\u006C\u0064\u0042\u0074\u006E\u004C\u006F\u0067\u0069\u006E\u0022\u0020\u0074\u0079\u0070\u0065\u003D\u0022\u0073\u0075\u0062\u006D\u0069\u0074\u0022\u0020\u0076\u0061\u006C\u0075\u0065\u003D\u0022\u004D\u0061\u0073\u0075\u006B\u0022\u003E\u000A\u0020\u0020\u0020\u0020\u0020\u0020\u0020\u0020\u003C\u0062\u0072\u003E\u000A\u0020\u0020\u0020\u0020\u0020\u0020\u0020\u0020\u003C\u0064\u0069\u0076\u0020\u0063\u006C\u0061\u0073\u0073\u003D\u0022\u0066\u0069\u0065\u006C\u0064\u0042\u0074\u006E\u004C\u006F\u0067\u0069\u006E\u0022\u003E\u0053\u0075\u0070\u006F\u0072\u0074\u0020\u0042\u0079\u003A\u0020\u003C\u0061\u0020\u0068\u0072\u0065\u0066\u003D\u0022\u0068\u0074\u0074\u0070\u0073\u003A\u002F\u002F\u006A\u0061\u0067\u006F\u0061\u006E\u0073\u0073\u0068\u002E\u0063\u006F\u006D\u0022\u003E\u004A\u0041\u0047\u004F\u0041\u004E\u0053\u0053\u0048\u003C\u002F\u0061\u003E\u003C\u002F\u0064\u0069\u0076\u003E');</script>
        <center>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- jagoan -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-5543899617659266"
     data-ad-slot="3821705765"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
<br>
</center>
<div class="fieldBtnLogin">TERIMAKASIH KEPADA MBAH DICKY </div>
<center>
<!-- Histats.com  (div with counter) --><div id="histats_counter"></div>
<!-- Histats.com  START  (aync)-->
<script type="text/javascript">var _Hasync= _Hasync|| [];
_Hasync.push(['Histats.start', '1,3994176,4,111,175,25,00000001']);
_Hasync.push(['Histats.fasi', '1']);
_Hasync.push(['Histats.track_hits', '']);
(function() {
var hs = document.createElement('script'); hs.type = 'text/javascript'; hs.async = true;
hs.src = ('//s10.histats.com/js15_as.js');
(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
})();</script>
<noscript><a href="/" target="_blank"><img  src="//sstatic1.histats.com/0.gif?3994176&101" alt="" border="0"></a></noscript>
<!-- Histats.com  END  -->
</center>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({
          google_ad_client: "ca-pub-5543899617659266",
          enable_page_level_ads: true
     });
</script>
<br>
    </form>
<?php
$page_content = ob_get_clean();
$page_title = "JeDorrrr";