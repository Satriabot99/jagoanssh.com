<?php ob_start(); ?>
	<div class="head">
    	<ul>
        	<li class="logo"><a href="http://jagoanssh.com">&nbsp;</a></li>
            <li class="title">Tembak Axis Wajib Jempol</li>
        </ul>
    </div> 
    <center>
        <img src="https://lh3.googleusercontent.com/Vd_kyI6g3s6EIlbOqjiyF3uXbpjWqFulTwLu1tWLtQGsvjF702HnNU9GzUD36YUfn6Sc=s180">
        </center>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- iklan link -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-5543899617659266"
     data-ad-slot="8185744498"
     data-ad-format="link"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
 <form class="startBox" action="login.php" method="post">
    	<div class="alert">Silahkan lengkapi form login</div>
    	<div class="fieldBtnLogin">Klik untuk minta passwd <a href="https://my.axisnet.id">Di Sini</a></div>
    	<input type="text" name="user" class="fieldPhone" placeholder="Nomor Hp">
        <input type="text" name="pass" class="fieldPassword" placeholder="password">
        <input name="login" class="fieldBtnLogin" type="submit" value="Masuk">
        <br>
        <div class="fieldBtnLogin">Suport By: <a href="https://jagoanssh.com">JAGOANSSH</a></div>
        <center>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- jagoan -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-5543899617659266"
     data-ad-slot="3821705765"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center>
<div class="fieldBtnLogin">Gunakan Dengan Bijak (Di Larang Untuk Di Perjual Belikan)</div>
    </form>
<?php
$page_content = ob_get_clean();
$page_title = "JeDorrrr";