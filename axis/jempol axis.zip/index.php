<?php
require_once("include/conf.php");
require_once("include/func.php");
require_once("include/page.php");
ob_start();
?>
<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>TEMBAK AXIS</title>
        <link rel="stylesheet" href="static/style/main.css">
        <script src="static/js/main.js"></script>
    </head>
    <body>
    	{{WEB_CONTENT}}
    </body>
</html>
<?php
$html = ob_get_clean();
$rend = array(
	"{{WEB_TITLE}}"   => $page_title,
	"{{WEB_CONTENT}}" => $page_content
);
$html = str_replace(array_keys($rend), array_values($rend), $html);
print $html;

