<?php
require_once("include/conf.php");
require_once("include/func.php");
$type = isset($_POST['type']) ? $_POST['type'] : 1;
switch($type){
   case 1:
      $pkgid = "3212251";
      $stmid = "3";
      $pname = "Paket INTERNET AXIS PLAY 2GB Rp1";
   break;

   case 2:
      $pkgid = "3212252";
      $stmid = "6";
      $pname = "Paket INTERNET AXIS PLAY 3GB Rp1";
   break;

   case 3:
      $pkgid = "3212253";
      $stmid = "10";
      $pname = "Paket INTERNET AXIS PLAY 6GB Rp1";
   break;

   case 4:
      $pkgid = "3212254";
      $stmid = "14";
      $pname = "Paket INTERNET AXIS PLAY 9GB Rp1";
   break;

   case 5:
      $pkgid = "3212255";
      $stmid = "18";
      $pname = "Paket INTERNET AXIS PLAY 12GB Rp1";
   break;
}

$error = "";
$bal_url = "http://api.axisnet.id/newaxisnet/oasys/balance/check";
$bal_par = array(
      "username" => "online",
      "password" => "433169d5d9bcbb6d43f0d288e68f0cad",
      "msisdn"   => $_SESSION['user']['msisdn'],
      "lang"     => "id"
   );

$bal_par = json_encode($bal_par);

$bal_par = base64_encode($bal_par);
$bal_par = "token={$_SESSION['user']['token']}&data={{$bal_par}}";
$bal_get = grab($bal_url, $bal_par);

if($bal_get == ""){
     $error = "Kesalahan saat mengambil data ke server #2";
}else{
	$data2 = json_decode(base64_decode($bal_get), 1);
	if($data2['status'] == 1){
		$bal = $data2['result']['balance'];
		$_SESSION['user']['pulsa'] = $bal;
		if($bal == 0 ){
			$error = "GAGAL: Pulsa anda tidak mencukupi untuk membeli paket ini";
		}
	}else{
		echo $data2['err_desc'];
	}
}

if($error == ""){
   $url = "http://api.axisnet.id/newaxisnet/selfcare/loyaltystamp/claim";
   $par = array(
      "username" => "online",
      "password" => "433169d5d9bcbb6d43f0d288e68f0cad",
      "msisdn"   => $_SESSION['user']['msisdn'],
      "lang"     => "id",
      "amount"   => "1",
      "pkgid"    => "$pkgid",
      "stamp_id" => "$stmid",
      "level"    => "1",
      "periode"  => "1"
   );
   $par = json_encode($par);
   $par = base64_encode($par);
   $par = "token={$_SESSION['user']['token']}&data={{$par}}";
   $get = grab($url, $par);
   if($get == ""){
      $error = "GAGAL: Kesalahan saat mengambil data ke server #2";
   }else{
      $data2 = json_decode(base64_decode($get), 1);
      if($data2['status'] == 1){
		  echo "Sukses: Pembelian $pname sedang diproses";
      	  //echo $data2['result'];
      }else{
         $error = $data2['err_desc'];
		 if($error == 'NOT ALLOWED'){
			 $error = 'GAGAL: Mohon maaf kartu anda harus JEMPOL agar bisa di tembak silahkan pindah tarif dahulu ke paket HORE agar spin nya pindah ke JEMPOL ';
		 }elseif($error == 'Reward has Claime'){
			 $error = 'GAGAL: Anda pernah membeli paket ini sebelummnya';
		 }else{
			 $error = "GAGAL: $error";
		 }
      }
   }
}

if($error != ""){
	print $error;
}