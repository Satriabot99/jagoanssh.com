<?php
include("include/conf.php");
unset($_SESSION['user']);
header("location:index.php");