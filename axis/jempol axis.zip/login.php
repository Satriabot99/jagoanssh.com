<?php
include("include/conf.php");
include("include/func.php");
$xuser = @$_POST['user'];
$xpass = @$_POST['pass'];


$url = "https://openwhisk.ng.bluemix.net/api/v1/web/axisnet_id/api/auth2.json?sada=kk";
$par = '{"user":"'.$xuser.'", "pass":"'.$xpass.'"}';
$get = grab($url, $par);
$error = "";

if($get == ""){
   $error = "Kesalahan saat mengambil data ke server";
}else{
   $data = json_decode($get, 1);
   if($data['status'] == "error"){
      $error = $data['reason'];
   }else{
      $token = $data['token'];
      $phone = $data['msisdn'];
	  $pulsa = $data['pulsa'];
   }
}

if($error == ""){
	echo "sucess";
	$_SESSION['user']['phone']  = $xuser;
	$_SESSION['user']['msisdn'] = $phone;
	$_SESSION['user']['token']  = $token;	
	$_SESSION['user']['pulsa']  = $pulsa;	
}else{
	$_SESSION['login_eror'] = $error;
}

header("location:index.php");