# final-website

- style changer, 0 = simple html || 1 = bootstrap

- loggedin session
- packageid censored, edit in "index.php $_POST['tembak']"
- curl disable ssl (performance) & prevent warning
- multikey support ( @ruj1H3rM4ty@r , debug@cepzdecoded ), edit in "module.php"
- manualid support if debug key is input.
- disable some warning & unused variable
- minor bug fixed

*Note: kehentaian bisa mempengaruhi keberhasilan :v\
~Cepzdecoded

